﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday
{
    public interface IAgeable
    {
        public int Age{get; }
    }
}
