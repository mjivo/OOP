﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday
{
    public interface INamable
    {
        public string Name { get; }
    }
}
