﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday
{
    public interface IModelable
    {
        public string Model{get; }
    }
}
