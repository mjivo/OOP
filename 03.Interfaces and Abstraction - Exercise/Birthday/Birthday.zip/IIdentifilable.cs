﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday
{
    public  interface IIdentifilable
    {
        public string Id { get; }
    }
}
