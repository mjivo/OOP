﻿namespace Telephony
{
    public interface IBrowsable
    {
        //public string URL { get; }

        public string Browse(string URL);

    }
}